# lambdasNodePack

# Export lambda pack
```bash
./tozip.sh
```

# raw command
```bash
zip -r lambdasNodePack.zip node_modules/
```
